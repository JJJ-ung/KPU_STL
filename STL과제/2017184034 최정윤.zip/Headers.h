#pragma once

#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <fstream>
#include <Windows.h>

using namespace std;
